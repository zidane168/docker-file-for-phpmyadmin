<?php

$i=0;
$i++;
$cfg['Servers'][$i]['auth_type']     = 'cookie';
// if you insist on "root" having no password:
//$cfg['Servers'][$i]['AllowNoPassword'] = true; `

//$cfg['Servers'][$i]['user']          = 'root';
//$cfg['Servers'][$i]['password']      = 'root'; // use here your password
//$cfg['Servers'][$i]['auth_type']     = 'config';
